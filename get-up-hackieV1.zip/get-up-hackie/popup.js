const $ = (id) => document.getElementById(id);

async function load() {
  const { usage = {}, exercises = 0, limitMin = 20 } =
    await chrome.storage.local.get(["usage", "exercises", "limitMin"]);
  const secs = usage[new Date().toDateString()] || 0;
  $("today").textContent = Math.floor(secs / 60) + " min";
  $("ex").textContent = exercises;
  $("limit").value = limitMin;
}

$("limit").addEventListener("change", () => {
  const v = Math.max(1, parseInt($("limit").value) || 20);
  chrome.storage.local.set({ limitMin: v });
});

$("test").addEventListener("click", async () => {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tabs[0]) {
    chrome.tabs.sendMessage(tabs[0].id, { type: "TEST_HACKIE", minutes: 20 })
      .catch(() => alert("Open YouTube or Instagram in this tab first (then refresh it)."));
  }
});

load();

$("reset").addEventListener("click", () => {
  chrome.storage.local.set({ nagging: false, snoozeUntil: 0, snoozeCount: 0, sinceNag: 0 });
});

// ---- test slider: drag to fake "minutes watched since last break" ----
const bar = $("bar");
let dragging = false;

function fmt(s) {
  s = Math.floor(s);
  return Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0");
}

async function refreshBar() {
  const d = await chrome.storage.local.get(["sinceNag", "limitMin", "nagging", "snoozeUntil"]);
  const limit = d.limitMin || 20;
  bar.max = limit * 60;
  const busy = d.nagging || (d.snoozeUntil && d.snoozeUntil > Date.now());
  bar.disabled = !!busy;
  if (!dragging) bar.value = d.sinceNag || 0;
  $("barVal").textContent = busy ? "paused (nag or snooze active)" : fmt(+bar.value) + " / " + limit + ":00";
}

bar.addEventListener("input", () => {
  dragging = true;
  $("barVal").textContent = fmt(+bar.value) + " / " + fmt(+bar.max);
  chrome.storage.local.set({ sinceNag: +bar.value }); // Hackie nags as soon as it reaches the limit
});
bar.addEventListener("change", () => { dragging = false; });

setInterval(() => { if (!dragging) refreshBar(); }, 1000);
refreshBar();
